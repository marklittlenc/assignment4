<?php 
	$conn = mysqli_connect("localhost","root","","db_comments") or die ('cannot connect to database' . mysqli_error());
?>