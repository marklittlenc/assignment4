<!DOCTYPE html>
<html>
<head>
	<title>ICTN 6845: Login and Commenting System</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="js/jquery-1.9.1.min.js"></script>
	<?php include('dbconn.php'); ?>
</head>

<body>
<center>
<H1> Welcome to the ICTN 6845 <br>Login and Commenting System</H1>
</center>
<TABLE>
<TR>
<TD>
	   <form id="login_form"  method="post">
	   <div class="wrapper">
        <h3><b>Existing User? Please login below:</b></h3>
		<hr>
        <label for="">Username</label><br/>
        <input type="text"  id="username" name="username" placeholder="Username" required><br><br>
        <label for="">Password</label><br/>
        <input type="password" id="password" name="password" placeholder="Password" required><br><br>
        <button name="login" type="submit">Sign in</button>
		</div>
		</form>
</TD>
<TD>
		<form method="POST" action="signup.php" id="signup">
		<div class="wrapper">
		        <h3>New User? Please register below:</h3>
				<hr>
        		<label for="">Username</label><br/>
				<input type="text" name="username" Placeholder="Username here.."><br><br>
        		<label for="">Password</label><br/>
				<input type="password" name="password" Placeholder="Password here.."><br><br>
        		<label for="">First Name</label><br/>
				<input type="text" name="firstname" Placeholder="First Name here.."><br><br>
        		<label for="">Last Name</label><br/>
				<input type="text" name="lastname" Placeholder="Last Name here.."><br><br>
				<input type="submit" name="save" value="Register">
				</div>
			</form>
</TD>
</TR>
</TABLE>

			<script>
			jQuery(document).ready(function(){
			jQuery("#login_form").submit(function(e){
					e.preventDefault();
					var formData = jQuery(this).serialize();
					$.ajax({
						type: "POST",
						url: "login.php",
						data: formData,
						success: function(html){
						if(html=='true')
						{
						$.jGrowl("Welcome Back!", { header: 'Access Granted' });
						var delay = 2000;
							setTimeout(function(){ window.location = 'home.php'  }, delay);  
						}
						else
						{
						$.jGrowl("Please Check your username and Password", { header: 'Login Failed' });
						}
						}
						
					});
					return false;
				});
			});
			</script> 
<?php include('scripts.php');?>

</body>
</html>